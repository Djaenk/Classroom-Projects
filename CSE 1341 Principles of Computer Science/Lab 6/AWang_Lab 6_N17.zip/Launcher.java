//Anthony Wang
//47733248
//Lab 6 - Fall 2018

public class Launcher{
	public static void main(String[] args){
		BatterUp game = new BatterUp();
		game.play();
	}
}