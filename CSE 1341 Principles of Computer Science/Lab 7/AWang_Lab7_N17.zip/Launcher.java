//Anthony Wang
//47733248
//Lab 7 - Fall 2018

import java.io.FileNotFoundException;

public class Launcher{
	public static void main(String[] args) throws FileNotFoundException{
		BatterUp game = new BatterUp();
		game.play();
	}
}